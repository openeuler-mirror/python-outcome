.. image:: https://img.shields.io/badge/chat-join%20now-blue.svg
   :target: https://gitter.im/python-trio/general
   :alt: Join chatroom

.. image:: https://img.shields.io/badge/docs-read%20now-blue.svg
   :target: https://outcome.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

.. image:: https://travis-ci.org/python-trio/trio.svg?branch=master
   :target: https://travis-ci.org/python-trio/outcome
   :alt: Automated test status (Linux and MacOS)

.. image:: https://ci.appveyor.com/api/projects/status/c54uu4rxlgs2usmj/branch/master?svg=true
   :target: https://ci.appveyor.com/project/RazerM/outcome/history
   :alt: Automated test status (Windows)

.. image:: https://codecov.io/gh/python-trio/trio/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/python-trio/outcome
   :alt: Test coverage

outcome
=======

Welcome to `outcome <https://github.com/python-trio/outcome>`__!

Capture the outcome of Python function calls. Extracted from the
`Trio <https://github.com/python-trio/trio>`__ project.

License: Your choice of MIT or Apache License 2.0
