======================================================
outcome: Capture the outcome of Python function calls.
======================================================

.. toctree::
   :maxdepth: 2

   tutorial.rst
   api.rst
   history.rst

====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
* :ref:`glossary`
