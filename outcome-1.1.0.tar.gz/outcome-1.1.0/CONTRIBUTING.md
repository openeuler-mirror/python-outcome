If you want to contribute to this code, please see the Trio contributing guide:
    https://trio.readthedocs.io/en/latest/contributing.html
