Please adhere to the Trio code of conduct. You can find it here:

    https://trio.readthedocs.io/en/latest/code-of-conduct.html
